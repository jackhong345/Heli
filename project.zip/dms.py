import numpy as np
import time
import cv2
# for face landmark detection
# import sys
# import os
import dlib
# import glob
# import imutils
from imutils import face_utils
# import json
#import pygame
# import skvideo.io
# import gc

# macro definitions
FILE_NAME = 'Val0001.jpg'
INPUT_FILE = '/home/admin/dms/model/' + FILE_NAME
VIDEO_FILE_PATH = "/home/admin/dms/model/3_ton_neiran_1.MOV"
OUTPUT_FILE = 'predicted.jpg'
OUTPUT_VIDEO_PATH = '/home/admin/dms/model/output.avi'
LABELS_FILE = '/home/admin/dms/model/data/face.names'
LABELS_FILE_HAND = '/home/admin/dms/model/data/hand_100K.names'
CONFIG_FILE = '/home/admin/dms/model/cfg/face.cfg'
CONFIG_FILE_HAND = '/home/admin/dms/model/cfg/hand_100K.cfg'
WEIGHTS_FILE = '/home/admin/dms/model/face_20000.weights'
WEIGHTS_FILE_HAND = '/home/admin/dms/model/hand_100K_8000.weights'
CONFIDENCE_THRESHOLD = 0.3

mmod_detector_path = "/home/admin/dms/dlib/mmod_human_face_detector.dat"
predictor_path = "/home/admin/dms/dlib/shape_predictor_68_face_landmarks.dat"
face_recognition_path = "/home/admin/dms/dlib/dlib_face_recognition_resnet_model_v1.dat"
Drive_permission_flag = False
driver_change_audio_flag = 0
use_yolo_for_face = False
dets_zero_use_yolo = True
no_face_frame_count = 0
Fatigue_flag_count = 0
Fatigue_flag_total_count = 0
Change_driver_flag = False
Fatigue_flag = False
Distraction_flag = False
Abnormal_flag = False
No_driver_flag = False
last_permitted_driver = 'other'
(x_hand, y_hand, w_hand, h_hand) = (0, 0, 0, 0)
(pitch, yaw, roll) = (0, 0, 0)
d = dlib.rectangle(0, 0, 0, 0)
class_face = 'other'

#pygame.mixer.init()
# pygame.display.init()
# screen = pygame.display.set_mode ( ( 420 , 240 ) )
# pygame.mixer.music.set_volume(1.0)
# welcome_audio = pygame.mixer.Sound('/home/jz262/PycharmProjects/adas/audio/welcome.wav')
# driver_change_audio = pygame.mixer.Sound('/home/jz262/PycharmProjects/adas/audio/driver_change.wav')
# fatigue_audio = pygame.mixer.Sound('/home/jz262/PycharmProjects/adas/audio/fatigue.wav')
welcome_audio_path = '/home/admin/dms/project/audio/welcome.wav'
not_registered_path = '/home/admin/dms/project/audio/not_registered.wav'
driver_change_audio_path = '/home/admin/dms/project/audio/driver_change.wav'
fatigue_audio_path = '/home/admin/dms/project/audio/fatigue.wav'
play_list = []
audio_play_flag = 0

# Should also include X, Y, Z as calibration when registering on specific machine
driver1_info = [0.66, 0.17, 1.19]  # REyeOp, SMouthOp, BMouthOp
driver2_info = [0.70, 0.037, 1.16]  # Register when recognising

# 3D model points for head pose estimation
model_points = np.array([
    (0.0, 0.0, 0.0),  # Nose tip
    (0.0, -330.0, -65.0),  # Chin
    (-225.0, 170.0, -135.0),  # Left eye left corner
    (225.0, 170.0, -135.0),  # Right eye right corne
    (-150.0, -150.0, -125.0),  # Left Mouth corner
    (150.0, -150.0, -125.0)  # Right mouth corner

])
# Draw a 3D box as annotation of head pose
reprojectsrc = np.float32([[10.0, 10.0, 10.0],
                           [10.0, 10.0, -10.0],
                           [10.0, -10.0, -10.0],
                           [10.0, -10.0, 10.0],
                           [-10.0, 10.0, 10.0],
                           [-10.0, 10.0, -10.0],
                           [-10.0, -10.0, -10.0],
                           [-10.0, -10.0, 10.0]])
line_pairs = [[0, 1], [1, 2], [2, 3], [3, 0],
              [4, 5], [5, 6], [6, 7], [7, 4],
              [0, 4], [1, 5], [2, 6], [3, 7]]
dist_coeffs = np.zeros((4, 1))  # Assuming no lens distortion

COLORS = np.random.randint(0, 255, size=(1, 3), dtype="uint8")

# label_file = open('/home/jz262/dlib-19.22/label_face.txt', 'r')
# label_face = json.load(label_file)
# label_face = np.loadtxt('/home/jz262/dlib-19.22/label_face.txt')
label_face = np.genfromtxt('/home/admin/dms/dlib/label_face.txt', dtype='str')
# label_file.close()
face_eigen = np.loadtxt('/home/admin/dms/dlib/face_eigen.txt')

verbose = False


# function definition
def get_head_pose(shape, landmarks_6P, cam_matrix):
    # image_pts = np.float32([shape[17], shape[21], shape[22], shape[26], shape[36],
    #                         shape[39], shape[42], shape[45], shape[31], shape[35],
    #                         shape[48], shape[54], shape[57], shape[8]])
    image_pts = np.float32(landmarks_6P)

    _, rotation_vec, translation_vec = cv2.solvePnP(model_points, image_pts, cam_matrix, dist_coeffs)

    reprojectdst, _ = cv2.projectPoints(reprojectsrc, rotation_vec, translation_vec, cam_matrix,
                                        dist_coeffs)

    reprojectdst = tuple(map(tuple, reprojectdst.reshape(8, 2)))

    # calc euler angle: X - pitch; Y - yaw; Z - roll
    rotation_mat, _ = cv2.Rodrigues(rotation_vec)
    pose_mat = cv2.hconcat((rotation_mat, translation_vec))
    _, _, _, _, _, _, euler_angle = cv2.decomposeProjectionMatrix(pose_mat)

    return reprojectdst, euler_angle

def is_overlap(box1, box2):
    if box1[0] > (box2[0] + box2[2]):
        return 0.0
    if box1[1] > (box2[1] + box2[3]):
        return 0.0
    if (box1[0] + box1[2]) < box2[0]:
        return 0.0
    if (box1[1] + box1[3]) < box2[1]:
        return 0.0
    col = min(box1[0] + box1[2], box2[0] + box2[2]) - max(box1[0], box2[0])
    row = min(box1[1] + box1[3], box2[1] + box2[3]) - max(box1[1], box2[1])
    intersection = col * row
    area1 = box1[2] * box1[3]
    area2 = box2[2] * box2[3]
    return float(intersection / (area1 + area2 - intersection))

def find_nearest_face(face_descriptor, faceLabel):
    temp = face_descriptor - face_eigen
    e = np.linalg.norm(temp, axis=1, keepdims = True)
    min_distance = e.min()
    if verbose:
        print('distance: ', min_distance)
    if min_distance > threshold_face:
        return 'other'
    index = np.argmin(e)
    return faceLabel[index]

def play_speech(title):
    # pygame.mixer.music.set_endevent(MUSIC_END)
    # print(title)
    #play_list.append(title)
    # print(play_list)
    # pygame.mixer.music.load(title)
    if not True: #pygame.mixer.music.get_busy():
        # pygame.mixer.music.queue(title)
        # pygame.mixer.music.play()
        return True
    else:
        # pygame.mixer.music.queue(title)
        # pygame.mixer.music.play()
        return False


# face landmark detection based on dlib 19.22
detector = dlib.get_frontal_face_detector()
# detector = dlib.cnn_face_detection_model_v1(mmod_detector_path)
predictor = dlib.shape_predictor(predictor_path)
recogniser = dlib.face_recognition_model_v1(face_recognition_path)
threshold_face = 0.54
# win = dlib.image_window()

start1 = time.time()
start_whole = time.time()

# print("Processing file: {}".format(f))
# cap = cv2.VideoCapture(VIDEO_FILE_PATH)
cap = cv2.VideoCapture(3)
# 获取视频帧的宽
w_video = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
# 获取视频帧的高
h_video = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
# 获取视频帧的帧率
# fps = round(cap.get(cv2.CAP_PROP_FPS))
fps = 30.0
# 获取视频流的总帧数
# video_frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
video_frame_count = fps * 100
# process_count = 0

# size = (h_video, w_video)
size = (w_video, h_video)
# size = (640, 480)
fourcc = cv2.VideoWriter_fourcc(*'XVID') # *XVID
# fourcc = -1
videoWriter = cv2.VideoWriter(OUTPUT_VIDEO_PATH, fourcc, fps, size)
#video表示视频路径，字符串形式，eg：‘E:/project/blink-detection/3.mp4’
# metadata = skvideo.io.ffprobe(VIDEO_FILE_PATH)

if verbose:
    print("按键Q - 结束视频录制")
# while(cap.isOpened()):
# for f in glob.glob(INPUT_FILE):
while True:
# while video_frame_count > 0:
# while process_count < 10:

    ret, img = cap.read()
    # img = cv2.resize(img, (0,0), fx=0.5, fy=0.5)
    # 如果帧获取正常
    if ret:
        # 镜像反转 flip
        img = cv2.flip(img, 0)
        # rotate 90 degree of the video frame
        # img = cv2.transpose(img)

        video_frame_count -= 1
        # process_count += 1
        if video_frame_count == 0:
            video_frame_count = fps * 100

        if video_frame_count % (fps / 2) == 0:
        # if video_frame_count % 10 == 0:
            # try:
            #     d = metadata['video'].get('tag')[0]
            #     if d.setdefault('@key') == 'rotate':  # 获取视频自选择角度
            #         img = imutils.rotate(img, 360 - int(d.setdefault('@value')))
            # except:
            #     pass

            # img = dlib.load_rgb_image(f)
            # img = cv2.imread(INPUT_FILE)
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            (H, W) = img.shape[:2]
            focal_length = W
            center = (W / 2, H / 2)
            cam_matrix = np.array(
                [[focal_length, 0, center[0]],
                 [0, focal_length, center[1]],
                 [0, 0, 1]], dtype="double"
            )

            # win.clear_overlay()
            # win.set_image(img)

            # Ask the detector to find the bounding boxes of each face. The 1 in the
            # second argument indicates that we should upsample the image 1 time. This
            # will make everything bigger and allow us to detect more faces.
            dets = detector(img, 1)
            if verbose:
                print("Number of faces detected: {}".format(len(dets)))
            if len(dets) == 0:
                use_yolo_for_face = dets_zero_use_yolo
            if use_yolo_for_face:
                # face detection using yolov3 based on OpenCV (>= 3.4.2)
                LABELS = open(LABELS_FILE).read().strip().split("\n")

                np.random.seed(4)

                net = cv2.dnn.readNetFromDarknet(CONFIG_FILE, WEIGHTS_FILE)

                # image = cv2.imread(INPUT_FILE)
                # (H, W) = img.shape[:2]

                # determine only the *output* layer names that we need from YOLO
                ln = net.getLayerNames()
                ln = [ln[i[0] - 1] for i in net.getUnconnectedOutLayers()]

                blob = cv2.dnn.blobFromImage(img, 1 / 255.0, (416, 416),
                                             swapRB=True, crop=False)
                net.setInput(blob)

                start = time.time()
                layerOutputs = net.forward(ln)
                end = time.time()
                if verbose:
                    print("[INFO] YOLO took {:.6f} seconds".format(end - start))

                # initialize our lists of detected bounding boxes, confidences, and
                # class IDs, respectively
                # also rectangles for the usage of dlib
                boxes = []
                confidences = []
                classIDs = []
                rects = []

                # loop over each of the layer outputs
                for output in layerOutputs:
                    # loop over each of the detections
                    for detection in output:
                        # extract the class ID and confidence (i.e., probability) of
                        # the current object detection
                        scores = detection[5:]
                        classID = np.argmax(scores)
                        confidence = scores[classID]

                        # filter out weak predictions by ensuring the detected
                        # probability is greater than the minimum probability
                        if confidence > CONFIDENCE_THRESHOLD:
                            # scale the bounding box coordinates back relative to the
                            # size of the image, keeping in mind that YOLO actually
                            # returns the center (x, y)-coordinates of the bounding
                            # box followed by the boxes' width and height
                            box = detection[0:4] * np.array([W, H, W, H])
                            (centerX, centerY, width, height) = box.astype("int")

                            # use the center (x, y)-coordinates to derive the top and
                            # and left corner of the bounding box
                            x = int(centerX - (width / 2))
                            y = int(centerY - (height / 2))

                            # update our list of bounding box coordinates, confidences,
                            # and class IDs
                            boxes.append([x, y, int(width), int(height)])
                            confidences.append(float(confidence))
                            classIDs.append(classID)

                # apply non-maxima suppression to suppress weak, overlapping bounding
                # boxes
                idxs = cv2.dnn.NMSBoxes(boxes, confidences, CONFIDENCE_THRESHOLD,
                                        CONFIDENCE_THRESHOLD)

                # ensure at least one detection exists
                if len(idxs) > 0:
                    # loop over the indexes we are keeping
                    for i in idxs.flatten():
                        # extract the bounding box coordinates
                        (x, y) = (boxes[i][0], boxes[i][1])
                        (w, h) = (boxes[i][2], boxes[i][3])

                        # color = [int(c) for c in COLORS[classIDs[i]]]
                        # cv2.rectangle(img, (x, y), (x + w, y + h), color, 2)
                        # text = "{}: {:.4f}".format(LABELS[classIDs[i]], confidences[i])
                        # cv2.putText(img, text, (x, y - 5), cv2.FONT_HERSHEY_SIMPLEX,
                        # 			0.5, color, 2)

                        # see the following link for conversion details
                        # https://stackoverflow.com/questions/34871740/convert-opencvs-rect-to-dlibs-rectangle
                        rects.append(dlib.rectangle(x, y, x + w - 1, y + h - 1))

                # Replace the original fault detected rectangle
                dets = rects
                if verbose:
                    print("Using yolov3 instead of the default HOG method")

            if len(dets) == 0:
                no_face_frame_count += 1
                if no_face_frame_count > 5:
                    # Decide whether the driver leaves the vehicle after a 5 seconds
                    Drive_permission_flg = False
                    No_driver_flag = True
            else:
                no_face_frame_count = 0
                for k, d in enumerate(dets):
                    if k >= 1:
                        break

                    # enlarge the landmark detection region to improve accuracy
                    x1 = d.left()
                    y1 = d.top()
                    x2 = d.right()
                    y2 = d.bottom()
                    w1 = x2 - x1
                    h1 = y2 - y1
                    box_face = (x1, y1, w1, h1)
                    # x1 -= 50
                    # y1 -= 50
                    # x2 += 50
                    # # y2 += 100
                    # d2 = dlib.rectangle(x1, y1, x2, y2)
                    # cv2.rectangle(img, (x1, y2), (x2, y1), (255, 255, 0), 2)

                    # print("Detection {}: Left: {} Top: {} Right: {} Bottom: {}".format(
                    #     k+1, d.left(), d.top(), d.right(), d.bottom()))

                    # Get the landmarks/parts for the face in box d.
                    shape = predictor(img, d)
                    # shape = predictor(img, d2)
                    shape_pose = face_utils.shape_to_np(shape)

                    end1 = time.time()
                    if verbose:
                        print("Part 0: {}, Part 1: {} ...".format(shape.part(0),
                                                                  shape.part(1)))
                        print("[INFO] Face detection took {:.6f} seconds".format(
                                                                end1 - start1))

                    # face recognition to verify drivers and decide permission of driving
                    if not Drive_permission_flag:
                        face_descriptor = recogniser.compute_face_descriptor(img, shape)
                        face_descriptor = np.array(face_descriptor)
                        class_face = find_nearest_face(face_descriptor, label_face)

                        # To check whether the driver is authorised
                        if class_face == 'other':
                            Drive_permission_flag = False
                            if audio_play_flag == 1:
                                play_speech(not_registered_path)
                        else:
                            Drive_permission_flag = True
                            if audio_play_flag == 1:
                                play_speech(welcome_audio_path)
                        if audio_play_flag == 0:
                            #pygame.mixer.music.load(welcome_audio_path)
                            #pygame.mixer.music.set_endevent(pygame.USEREVENT)
                            #pygame.mixer.music.play()
                            audio_play_flag = 1

                        # To monitor whether the driver is changed
                        if class_face == last_permitted_driver:
                            Change_driver_flag = False
                        else:
                            Change_driver_flag = True
                            if verbose:
                                print("The driver is: {}".format(class_face))
                            driver_change_audio_flag += 1
                            if driver_change_audio_flag > 1:
                                play_speech(driver_change_audio_path)
                                driver_change_audio_flag = 2
                            last_permitted_driver = class_face

                    for idx in range(0, 67):
                        pos1 = (shape.part(idx).x, shape.part(idx).y)
                        pos2 = (shape.part(idx + 1).x, shape.part(idx + 1).y)
                        cv2.circle(img, pos1, 1, (0, 0, 255), 2)
                    ###### cv2.putText(image, str(idx), pos, cv2.FONT_HERSHEY_SIMPLEX, 0.5, color = (0, 255, 0), 2)

                    # Draw the face landmarks on the screen.
                    # color = [int(c) for c in COLORS[0]]
                    # cv2.rectangle(img, (d.left(), d.bottom()), (d.right(), d.top()), (255, 0, 0), 2)
                    # cv2.putText(img, class_face, (d.left(), d.bottom() - 5),
                    #             cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)
                # 	win.add_overlay(shape)
                #
                # win.add_overlay(dets)
                img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
                Change_driver_flag = False ############
                if verbose:
                    print("The driver is changed? {}".format(Change_driver_flag))


                if Drive_permission_flag:
                    # Fatigue Monitor
                    REyeOp = (shape.part(42 - 1).y + shape.part(41 - 1).y
                              - shape.part(38 - 1).y - shape.part(39 - 1).y) / (
                                     shape.part(40 - 1).x - shape.part(37 - 1).x)

                    SMouthOp = (shape.part(66 - 1).y + shape.part(67 - 1).y + shape.part(68 - 1).y
                                - shape.part(62 - 1).y - shape.part(63 - 1).y - shape.part(64 - 1).y) / (
                                       shape.part(65 - 1).x - shape.part(61 - 1).x)

                    BMouthOp = (shape.part(57 - 1).y + shape.part(58 - 1).y + shape.part(59 - 1).y
                                - shape.part(51 - 1).y - shape.part(52 - 1).y - shape.part(53 - 1).y) / (
                                       shape.part(55 - 1).x - shape.part(49 - 1).x)

                    # if (SMouthOp > driver1_info[1] * 5.5) or (BMouthOp > driver1_info[2] * 1.8):
                    if BMouthOp > driver1_info[2] * 2.5:
                        Fatigue_flag = True
                    else:
                        Fatigue_flag = False

                    # maybe normalize
                    if verbose:
                        print("Image name: {}, REyeOp: {:7.3f}, SMouthOp: {:7.3f}, "
                              "BMouthOp: {:7.3f}".format(FILE_NAME, REyeOp, SMouthOp, BMouthOp))

                    # Distraction and fatigue mixed monitor
                    landmarks_6P = [(int(shape.part(31 - 1).x), int(shape.part(31 - 1).y)),
                                    (int(shape.part(9 - 1).x),  int(shape.part(9 - 1).y)),
                                    (int(shape.part(37 - 1).x), int(shape.part(37 - 1).y)),
                                    (int(shape.part(46 - 1).x), int(shape.part(46 - 1).y)),
                                    (int(shape.part(49 - 1).x), int(shape.part(49 - 1).y)),
                                    (int(shape.part(55 - 1).x), int(shape.part(55 - 1).y))]
                    reprojectdst, euler_angle = get_head_pose(shape_pose, landmarks_6P, cam_matrix)

                    for (x, y) in shape_pose:
                        cv2.circle(img, (x, y), 1, (0, 0, 255), -1)

                    # for start, end in line_pairs:
                    # 	cv2.line(img, reprojectdst[start], reprojectdst[end], (0, 0, 255))

                    pitch = euler_angle[0, 0]
                    yaw = euler_angle[1, 0]
                    roll = euler_angle[2, 0]

                    if -140 <= pitch <= 0:
                        Fatigue_flag_count += 1
                        Fatigue_flag_total_count += 1
                        # Decide distraction or fatigue after a few frames
                        Distraction_flag = False
                    else:
                        if Fatigue_flag_count >= 0 and Fatigue_flag_total_count < 3:
                            Fatigue_flag_total_count += 1
                    if Fatigue_flag_total_count >= 3:
                        if Fatigue_flag_count >= 2:
                            Fatigue_flag = True
                            Distraction_flag = False
                        else:
                            Fatigue_flag_count = 0
                            Fatigue_flag_total_count = 0

                    # yaw < 10 or yaw > 42 for driver 1
                    if (yaw < 25 or yaw > 43) and (pitch > 140 or pitch < -160):
                        Distraction_flag = True
                        Fatigue_flag = False
                    else:
                        Distraction_flag = False

                    if verbose:
                        print("The driver is fatigue? {}".format(Fatigue_flag))

                    if verbose:
                        print("The driver is distracted? {}".format(Distraction_flag))


                    # Abnormality detector
                    # Hand detection using yolov3 based on OpenCV (>= 3.4.2)
                    LABELS_HAND = open(LABELS_FILE_HAND).read().strip().split("\n")

                    np.random.seed(4)

                    net = cv2.dnn.readNetFromDarknet(CONFIG_FILE_HAND, WEIGHTS_FILE_HAND)

                    # image = cv2.imread(INPUT_FILE)
                    # (H, W) = img.shape[:2]

                    # determine only the *output* layer names that we need from YOLO
                    ln = net.getLayerNames()
                    ln = [ln[i[0] - 1] for i in net.getUnconnectedOutLayers()]

                    blob = cv2.dnn.blobFromImage(img, 1 / 255.0, (416, 416),
                                                 swapRB=True, crop=False)
                    net.setInput(blob)

                    start = time.time()
                    layerOutputs = net.forward(ln)
                    end = time.time()
                    if verbose:
                        print("[INFO] YOLO took {:.6f} seconds for detecting hands".format(end - start))

                    # initialize our lists of detected bounding boxes, confidences, and
                    # class IDs, respectively
                    # also rectangles for the usage of dlib
                    boxes_hand = []
                    confidences_hand = []
                    classIDs_hand = []
                    rects_hand = []

                    # loop over each of the layer outputs
                    for output in layerOutputs:
                        # loop over each of the detections
                        for detection in output:
                            # extract the class ID and confidence (i.e., probability) of
                            # the current object detection
                            scores = detection[5:]
                            classID = np.argmax(scores)
                            confidence = scores[classID]

                            # filter out weak predictions by ensuring the detected
                            # probability is greater than the minimum probability
                            if confidence > CONFIDENCE_THRESHOLD:
                                # scale the bounding box coordinates back relative to the
                                # size of the image, keeping in mind that YOLO actually
                                # returns the center (x, y)-coordinates of the bounding
                                # box followed by the boxes' width and height
                                box = detection[0:4] * np.array([W, H, W, H])
                                (centerX, centerY, width, height) = box.astype("int")

                                # use the center (x, y)-coordinates to derive the top and
                                # and left corner of the bounding box
                                x = int(centerX - (width / 2))
                                y = int(centerY - (height / 2))

                                # update our list of bounding box coordinates, confidences,
                                # and class IDs
                                boxes_hand.append([x, y, int(width), int(height)])
                                confidences_hand.append(float(confidence))
                                classIDs_hand.append(classID)

                    # apply non-maxima suppression to suppress weak, overlapping bounding
                    # boxes
                    idxs = cv2.dnn.NMSBoxes(boxes_hand, confidences_hand, CONFIDENCE_THRESHOLD, CONFIDENCE_THRESHOLD)

                    # ensure at least one detection exists
                    if len(idxs) > 0:
                        # loop over the indexes we are keeping
                        if verbose:
                            print("Hands detected!")
                        for i in idxs.flatten():
                            # extract the bounding box coordinates
                            (x_hand, y_hand) = (boxes_hand[i][0], boxes_hand[i][1])
                            (w_hand, h_hand) = (boxes_hand[i][2], boxes_hand[i][3])
                            box_hand = (x_hand, y_hand, w_hand, h_hand)

                            inters_rate = is_overlap(box_face, box_hand)
                            if inters_rate > 0:
                                Abnormal_flag = True
                                Fatigue_flag = False
                            else:
                                Abnormal_flag = False

                            if verbose:
                                print("Face and hand are intersected at a rate of: {}.".format(inters_rate))

                            # cv2.rectangle(img, (x_hand, y_hand), (x_hand + w_hand, y_hand + h_hand), (0, 255, 255), 2)
                            # text = "{}: {:.4f}".format(LABELS_HAND[classIDs_hand[i]], confidences_hand[i])
                            # cv2.putText(img, text, (x_hand, y_hand - 5), cv2.FONT_HERSHEY_SIMPLEX,
                            # 			0.5, color, 2)

                            # see the following link for conversion details
                            # https://stackoverflow.com/questions/34871740/convert-opencvs-rect-to-dlibs-rectangle
                            rects_hand.append(dlib.rectangle(x_hand, y_hand, x_hand + w_hand - 1, y_hand + h_hand - 1))

                    if verbose:
                        print("The driver status is abnormal? {}".format(Abnormal_flag))

    # cv2.rectangle(img, (d.left(), d.bottom()), (d.right(), d.top()), (255, 0, 0), 2)
    # cv2.putText(img, class_face, (d.left(), d.bottom() - 5),
    #             cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)
    #
    # cv2.rectangle(img, (x_hand, y_hand), (x_hand + w_hand, y_hand + h_hand), (0, 255, 255), 2)

    # for event in pygame.event.get():
    #     if event.type == pygame.USEREVENT:    # A track has ended
    #         if len ( play_list ) > 0:           # If there are more tracks in the queue...
    #             pygame.mixer.music.queue ( play_list.pop() ) # Q
#    if len(play_list) > 0:  # If there are more tracks in the queue...
        #pygame.mixer.music.queue(play_list.pop())  # Q
        

    # pre-set values for 1920 x 1080 resolution, needs to be scaled
    x_d = round(w_video / 96)
    y_d = round(h_video / 18)
    y_plus = round(h_video / 18)
    y_plus2 = round(y_plus / 6 * 7)
    font_size = 2 / 3
    thickness = round(4 / 3)
    thickness2 = round(5 / 3)

    cv2.putText(img, "X: " + "{:7.2f}".format(pitch), (x_d, y_d), cv2.FONT_HERSHEY_SIMPLEX,
                font_size, (0, 255, 255), thickness=thickness)
    cv2.putText(img, "Y: " + "{:7.2f}".format(yaw), (x_d, y_d + y_plus), cv2.FONT_HERSHEY_SIMPLEX,
                font_size, (0, 255, 255), thickness=thickness)
    cv2.putText(img, "Z: " + "{:7.2f}".format(roll), (x_d, y_d + y_plus * 2), cv2.FONT_HERSHEY_SIMPLEX,
                font_size, (0, 255, 255), thickness=thickness)

    if Change_driver_flag:
        cv2.putText(img, 'Driver changed!', (x_d, y_d + y_plus * 4), cv2.FONT_HERSHEY_SIMPLEX,
                    font_size, (0, 0, 255), thickness=thickness2)
    else:
        cv2.putText(img, 'Same driver', (x_d, y_d + y_plus * 4), cv2.FONT_HERSHEY_SIMPLEX,
                    font_size, (0, 255, 0), thickness=thickness)

    if Fatigue_flag:
        cv2.putText(img, 'Fatigue!', (x_d, y_d + y_plus * 4 + y_plus2), cv2.FONT_HERSHEY_SIMPLEX,
                    font_size, (0, 0, 255), thickness=thickness2)
        play_speech(fatigue_audio_path)
    else:
        cv2.putText(img, 'No Fatigue', (x_d, y_d + y_plus * 4 + y_plus2), cv2.FONT_HERSHEY_SIMPLEX,
                    font_size, (0, 255, 0), thickness=thickness)

    if Distraction_flag:
        cv2.putText(img, 'Distraction!', (x_d, y_d + y_plus * 4 + y_plus2 * 2), cv2.FONT_HERSHEY_SIMPLEX,
                    font_size, (0, 0, 255), thickness=thickness2)
    else:
        cv2.putText(img, 'No Distraction', (x_d, y_d + y_plus * 4 + y_plus2 * 2), cv2.FONT_HERSHEY_SIMPLEX,
                    font_size, (0, 255, 0), thickness=thickness)

    if Abnormal_flag:
        cv2.putText(img, 'Abnormality!', (x_d, y_d + y_plus * 4 + y_plus2 * 3), cv2.FONT_HERSHEY_SIMPLEX,
                    font_size, (0, 0, 255), thickness=thickness2)
    else:
        cv2.putText(img, 'Normal drive', (x_d, y_d + y_plus * 4 + y_plus2 * 3), cv2.FONT_HERSHEY_SIMPLEX,
                    font_size, (0, 255, 0), thickness=thickness)

    if No_driver_flag:
        cv2.putText(img, 'Fault Driving!', (x_d, y_d + y_plus * 4 + y_plus2 * 4), cv2.FONT_HERSHEY_SIMPLEX,
                    font_size, (0, 0, 255), thickness=thickness2)
    else:
        cv2.putText(img, 'Correct Driving', (x_d, y_d + y_plus * 4 + y_plus2 * 4), cv2.FONT_HERSHEY_SIMPLEX,
                    font_size, (0, 255, 0), thickness=thickness)

    if class_face != 'other':
        cv2.putText(img, 'Driver: ' + class_face, (x_d, y_d + y_plus * 6 + y_plus2 * 4), cv2.FONT_HERSHEY_SIMPLEX,
                    font_size, (0, 255, 0), thickness=thickness)
    else:
        cv2.putText(img, 'Unknown Driver!', (x_d, y_d + y_plus * 6 + y_plus2 * 4), cv2.FONT_HERSHEY_SIMPLEX,
                    font_size, (0, 0, 255), thickness=thickness2)

    # Output the frame image to a video file
    videoWriter.write(img)
    # show the output image
    # cv2.imwrite("head_pose" + FILE_NAME + ".png", img)
    ############cv2.imshow('ADAS + DMS', img)
    # cv2.waitKey(0)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

end_whole = time.time()
if verbose:
    print("The frame is processed using {:7.3f} seconds.".format(
            end_whole - start_whole))

# if ret:
#     del img
#     gc.collect()
cap.release()
videoWriter.release()
cv2.destroyAllWindows()
